<img width="3338" height="2363" alt="Github Action -AKS(1)" src="https://github.com/user-attachments/assets/955a06f3-9f89-4c94-9014-5b6b16de3e7b" />

